package com.test.json.service;

import com.test.json.dao.ConfigRepo;
import com.test.json.model.ConfigBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConfigService {

    private final ConfigRepo repo;

    @Autowired
    public ConfigService(ConfigRepo repo) {
        this.repo = repo;
    }

    public ConfigBean get(String appCode, String version){
        return repo.findOneByAppCodeAndVersion(appCode, version);
    }
    public ConfigBean save(ConfigBean configBean){
        return repo.save(configBean);
    }
    public List<ConfigBean> get(String appCode){
        return repo.findAllByAppCodeOrderByLastModifiedDateDesc(appCode);
    }
}
