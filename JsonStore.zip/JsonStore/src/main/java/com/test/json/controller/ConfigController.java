package com.test.json.controller;

import com.test.json.model.ConfigBean;
import com.test.json.service.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
public class ConfigController {

    @Autowired
    private ConfigService service;


    @RequestMapping(value = "/{appCode}/config/{version:.+}", method = RequestMethod.GET)
    public @ResponseBody String  get(@PathVariable String appCode, @PathVariable String  version){
        final  ConfigBean bean = service.get(appCode, version);
        if(bean != null)
            return bean.getConfig();
        else
            return "";
    }

    @RequestMapping(value = "/{appCode}/config/{version:.+}", method = RequestMethod.POST)
    public @ResponseBody ConfigBean  post(@PathVariable String appCode, @PathVariable String  version, @RequestBody String json){
        ConfigBean configBean = service.get(appCode, version);
        if(configBean == null){
            configBean = new ConfigBean();
            configBean.setAppCode(appCode);
            configBean.setVersion(version);
        }
        configBean.setConfig(json);
        configBean.setLastModifiedDate(new Date());
        return service.save(configBean);
    }
    @RequestMapping(value = "/{appCode}/config", method = RequestMethod.GET)
    public @ResponseBody
    List<ConfigBean> getAll(@PathVariable String appCode){
        return service.get(appCode);
    }
}
