package com.test.json.dao;

import com.test.json.model.ConfigBean;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConfigRepo extends CrudRepository<ConfigBean, Integer> {
    ConfigBean findOneByAppCodeAndVersion(String appCode, String version);
    List<ConfigBean> findAllByAppCodeOrderByLastModifiedDateDesc(String appCode);

}
