package com.test.json.service;

import com.test.json.dao.ConfigRepo;
import com.test.json.model.ConfigBean;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.same;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ConfigServiceTest {

    private ConfigService unit;
    private String appCode = "test";
    private String version ="r1";

    @Mock
    private ConfigRepo repo;

    @Before
    public void setup(){
        unit = new ConfigService(repo);
    }

    private ConfigBean getBean(){
        ConfigBean bean = new ConfigBean();
        bean.setAppCode(appCode);
        bean.setVersion(version);
        bean.setLastModifiedDate(new Date());
        return bean;
    }


    @Test
    public void whenICallGetByAppCodeAndVersionThenItShouldReturnMeConfigObject(){
        ConfigBean bean  = getBean();
        when(repo.findOneByAppCodeAndVersion(same(appCode), same(version))).thenReturn(bean);
        assertThat(unit.get(appCode, version),is(bean));
        verify(repo, times(1)).findOneByAppCodeAndVersion(anyString(), anyString());


    }

    @Test
    public void whenICallPostByAppCodeAndVersionThenItShouldSaveTheObject(){
        ConfigBean bean  = getBean();
        when(repo.save(eq(bean))).thenReturn(bean);
        assertThat(unit.save(bean),is(bean));
        verify(repo, times(1)).save(same(bean));


    }

    @Test
    public void whenICallGetAllByAppCodeThenItShouldReturnAllTheObjects(){
        ConfigBean bean  = getBean();
        when(repo.findAllByAppCodeOrderByLastModifiedDateDesc(same(appCode))).thenReturn(Lists.newArrayList(bean));
        List<ConfigBean> list = unit.get(appCode);
        assertThat(list, is(notNullValue()));
        assertThat(list.get(0),is(bean));
        assertThat(list.size(),is(1));
        verify(repo, times(1)).findAllByAppCodeOrderByLastModifiedDateDesc(same(appCode));


    }


}