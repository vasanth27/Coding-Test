import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.json.ConfigStoreApplication;
import com.test.json.dao.ConfigRepo;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {WebApplicationContext.class,ConfigStoreApplication.class })
public class ConfigRestControllerIT {

    @Autowired
    private WebApplicationContext webApplicationContext;


    private MockMvc mockMvc;


    @Autowired
    ConfigRepo repo;

    @Before
    public void setup(){
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

    }


    private String getJson() throws IOException {
        return IOUtils.toString(this.getClass().getClassLoader().getResourceAsStream("test.json"));
    }



    @Test
    public void whenIDoPostSHouldSaveTheObject() throws Exception {
        mockMvc.perform(post("/api/test/config/r1")
                .content(getJson())
                .contextPath("/api")
                .contentType(MediaType.APPLICATION_JSON)
        )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.version", is("r1")))
                .andExpect(jsonPath("$.appCode", is("test")))
                .andExpect(jsonPath("$.lastModifiedDate", is(notNullValue())))
        ;
    }

    @Test
    public void whenIDoGetShouldReturnSavedTheObject() throws Exception {
        mockMvc.perform(post("/api/test/config/r1")
                .content(getJson())
                .contextPath("/api")
                .contentType(MediaType.APPLICATION_JSON)
        )
                .andExpect(status().isOk())
        ;

        String content = mockMvc.perform(get("/api/test/config/r1").contentType(MediaType.APPLICATION_JSON).contextPath("/api")).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
       assertThat(new ObjectMapper().readValue(content, Map.class).get("test").toString(), is("Test"));
    }

    @Test
    public void whenIDoGetAllShouldReturnSavedTheObject() throws Exception {
        mockMvc.perform(post("/api/test/config/r1")
                .content(getJson())
                .contextPath("/api")
                .contentType(MediaType.APPLICATION_JSON)
        )
                .andExpect(status().isOk())
        ;

        mockMvc.perform(post("/api/test/config/r2")
                .content(getJson())
                .contextPath("/api")
                .contentType(MediaType.APPLICATION_JSON)
        )
                .andExpect(status().isOk())
        ;

        String content = mockMvc.perform(get("/api/test/config")
                .contentType(MediaType.APPLICATION_JSON)
                .contextPath("/api"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].version", is("r2")))
                .andExpect(jsonPath("$[1].version", is("r1")))
                .andReturn().getResponse().getContentAsString();
        assertThat(content, is(notNullValue()));
    }


}
